import os
from dotenv import load_dotenv
load_dotenv()

API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
BOT_TOKEN = os.getenv("BOT_TOKEN")

DOWNLOAD_DIR = "downloads"

FORCE_CHANNEL = os.getenv("FORCE_CHANNEL")  # @channelusername
WELCOME_PIC = os.getenv("WELCOME_PIC")      # telegram file_id
