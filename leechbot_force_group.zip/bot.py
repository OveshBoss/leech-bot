import os, asyncio
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ChatPermissions
import aria2p
from config import API_ID, API_HASH, BOT_TOKEN, DOWNLOAD_DIR, FORCE_CHANNEL, WELCOME_PIC

os.makedirs(DOWNLOAD_DIR, exist_ok=True)

app = Client("leechbot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

aria2 = aria2p.API(aria2p.Client(host="http://localhost", port=6800))

WELCOME_TEXT = (
    "ʜᴇʏ 👋 ᴡᴇʟᴄᴏᴍᴇ ᴛᴏ ᴛʜᴇ ʟᴇᴇᴄʜ ʙᴏᴛ.

"
    "➤ ᴛʜɪs ʙᴏᴛ ᴡᴏʀᴋs ᴏɴʟʏ ɪɴ ɢʀᴏᴜᴘs.
"
    "➤ sᴇɴᴅ ᴍᴀɢɴᴇᴛ / ᴛᴏʀʀᴇɴᴛ / ᴅɪʀᴇᴄᴛ ʟɪɴᴋ.
"
    "➤ ғᴀsᴛ ᴀɴᴅ sᴍᴀʀᴛ ʟᴇᴇᴄʜɪɴɢ."
)

JOIN_TEXT = (
    "ʏᴏᴜ ᴍᴜsᴛ ᴊᴏɪɴ ᴛʜᴇ ᴄʜᴀɴɴᴇʟ ᴛᴏ ᴜsᴇ ᴛʜɪs ʙᴏᴛ."
)

def join_button():
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton("ᴊᴏɪɴ ᴄʜᴀɴɴᴇʟ", url=f"https://t.me/{FORCE_CHANNEL.replace('@','')}")]]
    )

async def is_joined(user_id):
    try:
        member = await app.get_chat_member(FORCE_CHANNEL, user_id)
        return member.status in ("member", "administrator", "owner")
    except:
        return False

@app.on_message(filters.new_chat_members)
async def welcome(_, m):
    for user in m.new_chat_members:
        await app.restrict_chat_member(
            m.chat.id,
            user.id,
            ChatPermissions()
        )
        await m.reply_photo(
            photo=WELCOME_PIC,
            caption=WELCOME_TEXT,
            reply_markup=join_button()
        )

@app.on_message(filters.group & filters.text)
async def group_guard(_, m):
    if not await is_joined(m.from_user.id):
        await m.delete()
        await m.reply_text(JOIN_TEXT, reply_markup=join_button())
    else:
        await app.restrict_chat_member(
            m.chat.id,
            m.from_user.id,
            ChatPermissions(can_send_messages=True,
                            can_send_media_messages=True,
                            can_send_polls=True,
                            can_send_other_messages=True,
                            can_add_web_page_previews=True)
        )

@app.on_message(filters.group & filters.text & ~filters.command("start"))
async def leech(_, m):
    link = m.text.strip()
    msg = await m.reply_text("⬇️ ᴅᴏᴡɴʟᴏᴀᴅɪɴɢ...")

    dl = aria2.add_uris([link], options={"dir": DOWNLOAD_DIR})

    while not dl.is_complete:
        await asyncio.sleep(5)
        dl.update()
        await msg.edit(f"⬇️ {dl.progress}% | {dl.download_speed_string()}")

    for f in dl.get_files():
        if f.path.lower().endswith((".mp4",".mkv",".avi",".mov",".webm")):
            await m.reply_video(f.path)
        else:
            await m.reply_document(f.path)

    await msg.edit("✅ ᴄᴏᴍᴘʟᴇᴛᴇᴅ")

app.run()
