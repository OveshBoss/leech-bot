import os, asyncio
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ChatPermissions
import aria2p, gdown
from config import API_ID, API_HASH, BOT_TOKEN, DOWNLOAD_DIR, FORCE_CHANNEL, WELCOME_PIC

os.makedirs(DOWNLOAD_DIR, exist_ok=True)

app = Client("leechbot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)
aria2 = aria2p.API(aria2p.Client(host="http://localhost", port=6800))

WELCOME_TEXT = (
    "ʜᴇʏ 👋 ᴡᴇʟᴄᴏᴍᴇ ᴛᴏ ᴛʜᴇ ʟᴇᴇᴄʜ ʙᴏᴛ.\n\n"
    "➤ ᴛʜɪs ʙᴏᴛ ᴡᴏʀᴋs ᴏɴʟʏ ɪɴ ɢʀᴏᴜᴘs.\n"
    "➤ sᴇɴᴅ ᴍᴀɢɴᴇᴛ / ᴛᴏʀʀᴇɴᴛ / ɢᴅʀɪᴠᴇ / ᴅɪʀᴇᴄᴛ ʟɪɴᴋ."
)

def join_button():
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton("ᴊᴏɪɴ ᴄʜᴀɴɴᴇʟ", url=f"https://t.me/{FORCE_CHANNEL.replace('@','')}")]]
    )

async def is_joined(uid):
    try:
        m = await app.get_chat_member(FORCE_CHANNEL, uid)
        return m.status in ("member","administrator","owner")
    except:
        return False

@app.on_message(filters.new_chat_members)
async def welcome(_, m):
    for u in m.new_chat_members:
        await app.restrict_chat_member(m.chat.id, u.id, ChatPermissions())
        await m.reply_photo(WELCOME_PIC, caption=WELCOME_TEXT, reply_markup=join_button())

@app.on_message(filters.group & filters.text)
async def guard(_, m):
    if not await is_joined(m.from_user.id):
        await m.delete()
        await m.reply_text("ʏᴏᴜ ᴍᴜsᴛ ᴊᴏɪɴ ᴛʜᴇ ᴄʜᴀɴɴᴇʟ ᴛᴏ ᴜsᴇ ᴛʜɪs ʙᴏᴛ.", reply_markup=join_button())
        return

    link = m.text.strip()
    msg = await m.reply_text("⬇️ ᴘʀᴏᴄᴇssɪɴɢ...")

    if "drive.google.com" in link:
        await msg.edit("⬇️ ᴅᴏᴡɴʟᴏᴀᴅɪɴɢ ғʀᴏᴍ ɢᴏᴏɢʟᴇ ᴅʀɪᴠᴇ...")
        gdown.download(link, DOWNLOAD_DIR, quiet=False, fuzzy=True)
    else:
        dl = aria2.add_uris([link], options={"dir": DOWNLOAD_DIR})
        while not dl.is_complete:
            await asyncio.sleep(5)
            dl.update()
            await msg.edit(f"⬇️ {dl.progress}% | {dl.download_speed_string()}")

    for root, _, files in os.walk(DOWNLOAD_DIR):
        for f in files:
            p = os.path.join(root, f)
            if p.lower().endswith((".mp4",".mkv",".avi",".mov",".webm")):
                await m.reply_video(p)
            else:
                await m.reply_document(p)

    await msg.edit("✅ ᴄᴏᴍᴘʟᴇᴛᴇᴅ")

app.run()
