import os, asyncio
from pyrogram import Client, filters
import aria2p
from config import API_ID, API_HASH, BOT_TOKEN, DOWNLOAD_DIR

os.makedirs(DOWNLOAD_DIR, exist_ok=True)

app = Client("leechbot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

aria2 = aria2p.API(aria2p.Client(host="http://localhost", port=6800))

@app.on_message(filters.command("start"))
async def start(_, m):
    await m.reply_text("Send magnet / torrent / direct link")

@app.on_message(filters.text & ~filters.command("start"))
async def leech(_, m):
    link = m.text.strip()
    msg = await m.reply_text("Downloading...")
    dl = aria2.add_uris([link], options={"dir": DOWNLOAD_DIR})

    while not dl.is_complete:
        await asyncio.sleep(5)
        dl.update()
        await msg.edit(f"{dl.progress}% | {dl.download_speed_string()}")

    for f in dl.get_files():
        if f.path.lower().endswith((".mp4",".mkv",".avi",".mov",".webm")):
            await m.reply_video(f.path)
        else:
            await m.reply_document(f.path)

app.run()
